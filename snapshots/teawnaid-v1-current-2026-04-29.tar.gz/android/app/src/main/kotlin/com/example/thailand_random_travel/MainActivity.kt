package com.example.thailand_random_travel

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
